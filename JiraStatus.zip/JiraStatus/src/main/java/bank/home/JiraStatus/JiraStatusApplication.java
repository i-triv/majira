package bank.home.JiraStatus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JiraStatusApplication {

	public static void main(String[] args) {
		SpringApplication.run(JiraStatusApplication.class, args);
	}

}
